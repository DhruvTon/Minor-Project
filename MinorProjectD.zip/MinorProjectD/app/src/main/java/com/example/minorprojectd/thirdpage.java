package com.example.minorprojectd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class thirdpage extends AppCompatActivity {
    Button fact;
    Button fourth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirdpage);

        fact = (Button) findViewById(R.id.button3);
        fact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast=Toast.makeText(getApplicationContext(), "Android's version are based on names of sweet stuff", Toast.LENGTH_LONG);
                toast.show();
                Intent intent3 = new Intent (thirdpage.this, androidfacts.class);
                startActivity(intent3);
            }
        });

        fourth = (Button) findViewById(R.id.button4);
        fourth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent (thirdpage.this, fourthpage.class);
                startActivity(intent2);
            }
        });
    }
}